# Agent Instructions

This project is the frontend for CoinData. It is intentionally separated from the CoinData backend Gradle multi-module project.

At the start of work, read these documents first:

1. `CLAUDE.md`
2. `FRONTEND_PLAN.md`
3. `STRUCTURE.md`

Use those documents as the source of truth for product direction, API integration, screen structure, and design rules.

## Priorities

1. Use `CLAUDE.md` as the project source of truth.
2. If implementation and documentation disagree, trust the implementation first and update the documentation when possible.
3. Reference CoinGecko only for market-data density and information architecture. Do not copy its branding, logo, exact layout, copy, color system, or visual identity.
4. The first screen must be a usable premium-focused dashboard, not a landing page.
5. CoinData Web is a kimchi-premium monitoring product, not a generic crypto-price clone.

## Frontend Stack

- React
- TypeScript
- Vite
- TanStack Query for REST API state
- EventSource for SSE
- Zustand or React state for lightweight client UI state
- Lightweight Charts or ECharts for charts
- CSS Modules, Tailwind CSS, or plain CSS may be used, but choose one primary styling approach and keep it consistent.

## Design Rules

- Light mode is the default.
- Keep the interface dense, calm, and data-first.
- Prefer search, filters, sorting, tables, and charts over large marketing sections.
- Do not implement a premium heatmap.
- Do not use category tabs such as "All", "DeFi", "NFT", etc. as the main navigation pattern.
- Use search and detailed filters instead of broad category tabs.
- Always distinguish buy-side premium and sell-side premium.
- The default chart is a candlestick chart.
- Investment indicators should be supported as chart overlays or panels.
- Economic events and news should be designed as timeline markers or chart overlays.

## Scope Discipline

- Do not place frontend files inside the backend `demo` project.
- Do not introduce authentication, watchlist, or alert UI until the backend user layer exists.
- Do not create decorative hero pages, gradient-orb backgrounds, or purely atmospheric visuals.
- Before changing more than 10 files in a structural refactor, check git status and report the planned scope.

## Validation

Prefer targeted validation while developing:

```powershell
npm run build
npm run lint
```

If tests are added:

```powershell
npm test
```

