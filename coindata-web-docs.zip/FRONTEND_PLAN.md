# Frontend Implementation Plan

## Phase 1. Project Setup

Create a new frontend project outside the backend repository.

Recommended location:

```text
C:\Users\smj\Desktop\COIN_SERVER\coindata-web
```

Recommended setup:

```powershell
npm create vite@latest coindata-web -- --template react-ts
cd coindata-web
npm install
```

Recommended dependencies:

```powershell
npm install @tanstack/react-query
npm install lightweight-charts
npm install zustand
npm install lucide-react
```

Optional:

```powershell
npm install echarts echarts-for-react
```

Use either Lightweight Charts or ECharts as the primary charting library. Prefer Lightweight Charts for trading-style candlesticks. Consider ECharts if economic/news overlays and complex panels become more important than trading-chart fidelity.

Deliverables:

- Vite React TypeScript app
- Routing
- Query provider
- Environment config
- Global styles/design tokens
- Build passes

Validation:

```powershell
npm run build
```

## Phase 2. App Shell

Build the main application shell.

Required elements:

- Header
- Brand text: `CoinData`
- Compact market stat strip
- Main content layout
- Search area
- Shared loading state
- Shared error state
- Shared empty state

Rules:

- Do not build a landing page.
- Do not build a marketing hero.
- The first screen should be a working dashboard.

## Phase 3. Premium Dashboard

Build the premium-first dashboard.

Required sections:

- Search input
- Detailed filter bar
- Premium ranking table
- Stream status indicator
- Chart preview area

Do not implement:

- Premium heatmap
- Generic category tabs

Filter candidates:

- Asset symbol
- Domestic exchange
- Offshore exchange
- Quote currency
- Buy premium min/max
- Sell premium min/max
- 1h change min/max
- 24h change min/max
- Volume min
- Freshness threshold
- Show elevated premium only

Table columns:

- Asset
- Domestic exchange
- Offshore exchange
- Domestic bid
- Offshore ask
- Buy premium
- Domestic ask
- Offshore bid
- Sell premium
- 1h
- 24h
- Volume
- Last update
- Sparkline

Expected behavior:

- Sort by premium, change, volume, and last update.
- Row click opens Market Detail.
- Fresh SSE updates can briefly highlight changed rows.

## Phase 4. Market Detail

Build the market detail page for an asset and exchange pair.

Required sections:

- Header with asset/exchange pair
- Buy-side and sell-side premium summary
- Candlestick chart
- Indicator controls
- Economic/news timeline markers
- Recent premium records

Chart controls:

- Timeframe
- RSI toggle
- MACD toggle
- Bollinger toggle
- Economic events toggle
- News toggle
- Premium band toggle

Initial implementation may use mock marker data if backend marker APIs are not ready.

## Phase 5. REST API Integration

Create API clients and query hooks.

Target API areas:

- Market latest data
- Premium snapshot/ranking
- Premium series
- Candle series
- Indicator series
- Economic calendar
- News timeline if available later

Rules:

- Components should not call `fetch` directly.
- Keep API calls in `features/*/api` or `shared/api`.
- Keep query keys centralized.
- Use adapters/mappers when backend DTOs are not UI-friendly.

## Phase 6. SSE Live Data

Build SSE clients.

Streams:

- Tick stream
- Premium stream
- Candle close stream
- Indicator close stream

UI requirements:

- Connected state
- Reconnecting state
- Disconnected/stale state
- Last event time
- Row highlight on fresh updates

Rules:

- Keep EventSource logic outside components.
- Do not let SSE event parsing spread across pages.
- Keep stream types explicit.

## Phase 7. Chart Overlays

Add chart overlay structure.

Initial supported overlays:

- RSI
- MACD
- Bollinger Bands
- Premium line/band
- Economic event markers
- News markers

Economic/news markers should be time-aligned to the chart.

Marker data shape should support:

- id
- timestamp
- type
- title
- severity
- source
- optional URL

## Phase 8. Polish

Polish work:

- Responsive layout
- Table horizontal scroll behavior
- Skeleton loading
- Empty states
- Error retry actions
- Chart tooltip
- Filter persistence
- URL query synchronization
- Keyboard-friendly search

## Phase 9. Later Scope

Implement only after backend support exists:

- JWT login
- User profile
- Watchlist
- Alert rule CRUD
- Alert history
- Admin views
- API key management

