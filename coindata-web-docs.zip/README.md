# CoinData Web Docs

These files are intended to be copied into a new frontend project such as:

```text
C:\Users\smj\Desktop\COIN_SERVER\coindata-web
```

Copy these files to the new project root:

- `AGENTS.md`
- `CLAUDE.md`
- `FRONTEND_PLAN.md`
- `STRUCTURE.md`

Recommended frontend stack:

- React
- TypeScript
- Vite
- TanStack Query
- EventSource/SSE
- Lightweight Charts or ECharts

