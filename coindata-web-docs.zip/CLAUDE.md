# CoinData Web Project Context

## 0. Overview

`coindata-web` is the frontend application for CoinData. It visualizes market data, kimchi premium, candlestick charts, technical indicators, economic events, news markers, and SSE live streams from the CoinData backend.

The backend is a separate project:

```text
CoinData backend: demo
CoinData frontend: coindata-web
```

The frontend should be developed in its own project directory, for example:

```text
C:\Users\smj\Desktop\COIN_SERVER\coindata-web
```

Do not mix this frontend project into the backend Gradle multi-module repository unless explicitly requested.

## 1. Product Direction

CoinData Web is not a generic cryptocurrency listing site. It is a premium-first market monitoring dashboard focused on Korean kimchi premium and cross-exchange spread behavior.

The first screen should help users quickly answer:

- Which asset has the highest premium right now?
- What is the buy-side premium?
- What is the sell-side premium?
- Which domestic and offshore exchange pair is being compared?
- Is the premium expanding or compressing?
- Is the move connected to a candle pattern, technical indicator, economic event, or news event?
- Is the data fresh and streaming?

## 2. Design Reference

Use CoinGecko as a broad reference for:

- Dense market-data layout
- Compact global market stat strip
- Prominent search
- Sortable tables
- Fast scanning of price, change, and volume
- Clear market-state colors

Do not copy:

- CoinGecko brand
- CoinGecko logo
- CoinGecko color palette directly
- Exact page layout
- Exact table structure
- Category-tab-first navigation
- Marketing copy

## 3. First Screen

The dashboard first viewport should include:

- Compact market stat strip
- Brand and navigation
- Search input
- Detailed filter controls
- Premium ranking table
- Stream connection state
- A visible chart preview or chart section

Do not include a premium heatmap.

Do not lead with broad category tabs such as:

```text
All / DeFi / NFT / Meme / Layer 1
```

Use search and detailed filters instead.

## 4. Premium Table

The premium table is the core of the first screen.

Recommended columns:

- Asset
- Domestic exchange
- Offshore exchange
- Domestic bid
- Offshore ask
- Buy-side premium
- Domestic ask
- Offshore bid
- Sell-side premium
- 1h change
- 24h change
- Volume
- Last update
- Sparkline

Premium must not be represented as a single ambiguous value.

Use explicit labels:

```text
Buy Premium
Sell Premium
```

Korean UI labels may use:

```text
매수 프리미엄
매도 프리미엄
```

## 5. Chart Direction

The default chart is a candlestick chart.

Chart capabilities should be structured to support:

- Candlestick OHLC
- Premium line or premium band
- RSI
- MACD
- Bollinger Bands
- Volume
- Economic event markers
- News timeline markers

Economic and news overlays should be timeline-based, not separate disconnected widgets.

Example event markers:

- CPI
- FOMC
- US Jobs
- Fed speech
- ETF news
- Exchange incident
- Regulatory headline

## 6. Main Screens

### Dashboard

Premium-first overview.

Includes:

- Market stat strip
- Search
- Filter bar
- Premium ranking table
- Live stream state
- Chart preview
- Economic/news timeline preview

### Market Detail

Detailed view for one asset and exchange pair.

Includes:

- Candlestick chart
- Premium overlays
- Indicator controls
- Economic/news markers
- Bid/ask premium breakdown
- Recent premium table

### Economic Timeline

Economic events and important news in time order.

Should be usable both as:

- a standalone page
- chart overlay data

### Later User Screens

Only after backend support exists:

- Login
- Watchlist
- Alert rules
- Alert history
- Admin views

## 7. API Integration Principles

REST API:

- Use TanStack Query.
- Keep query keys centralized.
- Keep API client code separate from UI components.
- Map backend DTOs into frontend view models when necessary.

SSE:

- Use `EventSource`.
- Keep stream clients under the `stream` feature.
- Show connection state in the UI.
- Handle reconnecting and stale data states.

Formatting:

- Use shared formatters for premium, price, volume, percent, and time.
- Keep raw numeric values available for sorting.

## 8. MVP Scope

MVP includes:

- Dashboard
- Premium search and detailed filters
- Premium ranking table
- Buy-side and sell-side premium display
- Market detail page
- Candlestick chart
- Indicator overlay controls
- Economic/news marker structure
- SSE-ready live update layer
- Loading, empty, and error states

MVP excludes:

- Premium heatmap
- Generic category tabs
- Login
- Watchlist
- Alert rule management
- Admin dashboard

## 9. Visual Tone

Use a calm fintech dashboard style.

Preferred:

- Light neutral background
- White or near-white surfaces
- Subtle gray borders
- Green/red/amber market semantics
- Small teal or blue accent
- Dense but readable table layout

Avoid:

- Purple-heavy gradients
- Dark slate-heavy theme
- Beige/brown/orange dominant palette
- Decorative blobs or orbs
- Oversized hero typography
- Marketing landing-page composition

